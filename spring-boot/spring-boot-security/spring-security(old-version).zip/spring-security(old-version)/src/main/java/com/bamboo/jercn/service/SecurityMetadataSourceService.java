package com.bamboo.jercn.service;

import org.springframework.security.access.ConfigAttribute;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 */
public interface SecurityMetadataSourceService {

    /**
     * 加载所有角色与权限的关系
     * @return
     */
    Map<String, Collection<ConfigAttribute>> loadResourceAndRoleRelation();
}
