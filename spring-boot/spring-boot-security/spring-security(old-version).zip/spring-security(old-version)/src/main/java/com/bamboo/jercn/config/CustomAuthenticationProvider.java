package com.bamboo.jercn.config;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

/**
 * @author Administrator
 */
public class CustomAuthenticationProvider extends DaoAuthenticationProvider {

//    @Autowired
//    private UserService userService;
//    @Autowired
//    private MessageHelper messageHelper;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        try {
            Authentication auth = super.authenticate(authentication);



            // 重置登录错误次数
//            userService.resetFailNums(authentication.getName());

            return auth;
        } catch (BadCredentialsException e) {
            e.printStackTrace();
            /*// 登录出错+1
            User user = userService.updateFailNums(authentication.getName());
            if(user != null && user.getId() != null) {
                // 判断是帐号是否已经锁定
                if (YesOrNoEnum.getByCode(user.getLocked()).equals(YesOrNoEnum.Y)) {
                    int num = user.getLoginErrorCount();
                    throw new LockedException(messageHelper.getMessage("AbstractUserDetailsAuthenticationProvider.login.account.locked", new Object[]{num}));
                }
            }
            // 剩于机会
            int num = userService.getLoginSurplusNums(user);
            throw new BadCredentialsException(messageHelper.getMessage("AbstractUserDetailsAuthenticationProvider.login.password.error", new Object[]{num}));*/
        }
        return null;
    }

}