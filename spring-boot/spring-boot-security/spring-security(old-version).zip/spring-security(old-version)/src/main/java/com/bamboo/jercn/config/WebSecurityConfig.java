package com.bamboo.jercn.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.servlet.configuration.EnableWebMvcSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;

import javax.sql.DataSource;

/**
 * 步骤2: 配置SecurityConfig
 * Created by bamboo on 2017/4/30.
 * @see http://www.cnblogs.com/softidea/p/5991897.html
 * @see http://www.w2bc.com/article/221107
 */
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableWebMvcSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired  //必须要通过注入(让Spring托管， 因为这个类里面调用service层， service调用repository层，他们都是spring托管的)
    private CustomUserDetailsService customUserDetailsService;  //code 1

    @Autowired @Qualifier("dataSource1")  // 指定记住登录信息所使用的数据源
    private DataSource dataSource; //code 2

//    @Autowired
//    private SecurityMetadataSourceService securityMetadataSourceService;

    /**
     * 设置不拦截规则
     * @param web
     * @throws Exception
     */
    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/js/**", "/css/**", "/images/**", "/**/favicon.ico");
    }

    protected void configure(HttpSecurity httpSecurity) throws Exception {
        // 关闭csrf
        httpSecurity.csrf().disable()
        //允许所有用户访问”/”和”/home” 和 允许所有用户访问”/login”
        .authorizeRequests().antMatchers("/", "/home", "/login", "login.html").permitAll()
        //其他地址的访问均需验证权限
        .anyRequest().authenticated()

        .and()
        .formLogin()    //.usernameParameter("username").passwordParameter("password").loginProcessingUrl("/login")
        //指定登录页是”/login”
        .loginPage("/login").permitAll()
        //登录成功后可使用loginSuccessHandler()存储用户信息，可选。
        .successHandler(loginSuccessHandler())  //code 3

        .and()
        .logout()
        .logoutUrl("/logout")
        //退出登录后的默认网址是”/home”
        .logoutSuccessUrl("/home").permitAll()
        .invalidateHttpSession(true)

        .and()
        .exceptionHandling().accessDeniedPage("/403")  // 无权限

        .and()
        //登录后记住用户，下次自动登录
        //数据库中必须存在名为persistent_logins的表
        //建表语句见code 15
        .rememberMe()
        .tokenValiditySeconds(1209600)
        //指定记住登录信息所使用的数据源
        .tokenRepository(tokenRepository())  //code 4

        .and()  // session 管理
        .sessionManagement()
        .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
        .sessionFixation().changeSessionId()
        .maximumSessions(1)
        .maxSessionsPreventsLogin(false)
        .expiredUrl("/login")
        .sessionRegistry(sessionRegistry());

        ;

        // 配置过滤
//        httpSecurity.addFilterBefore(customSecurityResourceFilter(), FilterSecurityInterceptor.class);
    }



    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        //指定密码加密所使用的加密器为passwordEncoder()
        //需要将密码加密后写入数据库 //code 13
//        auth.userDetailsService(userDetailsService()).passwordEncoder(passwordEncoder()); //code 5


        //添加自定义的userdetailservice认证
        auth.userDetailsService(customUserDetailsService);

        //see http://somefuture.iteye.com/blog/2282517
//        auth.jdbcAuthentication().dataSource(dataSource).usersByUsernameQuery("select username,password from s_user where username=?")
//                .authoritiesByUsernameQuery("select username, role from s_role where uid=?");



//        auth.authenticationProvider(authenticationProvider());


        //不删除凭据，以便记住用户
        auth.eraseCredentials(false);
    }



    // Code3----------------------------------------------
    @Bean
    public LoginSuccessHandler loginSuccessHandler(){
        return new LoginSuccessHandler();//code 6
    }

    // Code4----------------------------------------------
    @Bean
    public JdbcTokenRepositoryImpl tokenRepository(){
        JdbcTokenRepositoryImpl j = new JdbcTokenRepositoryImpl();
        j.setDataSource(dataSource);
        return j;
    }

    // Code5----------------------------------------------
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(4);
    }


//    @Bean
//    public UserDetailsService userDetailsService() {
//        CustomUserDetailsService customUserDetailsService = new CustomUserDetailsService();
//        return customUserDetailsService;
//    }

    @Bean
    public SessionRegistry sessionRegistry() {
        SessionRegistry sessionRegistry = new SessionRegistryImpl();
        return sessionRegistry;
    }

    /*@Bean
    public CustomAccessDescisionManager customAccessDescisionManager(){
        CustomAccessDescisionManager customAccessDescisionManager = new CustomAccessDescisionManager();
        return customAccessDescisionManager;
    }

    @Bean
    public CustomSecurityMetadataSource customSecurityMetadataSource(){
        CustomSecurityMetadataSource customSecurityMetadataSource = new CustomSecurityMetadataSource(securityMetadataSourceService);
        return customSecurityMetadataSource;
    }

    public CustomSecurityResourceFilter customSecurityResourceFilter() throws Exception {
        //CustomSecurityInterceptor customSecurityInterceptor = new CustomSecurityInterceptor();
        CustomSecurityResourceFilter customSecurityInterceptor = new CustomSecurityResourceFilter();
        customSecurityInterceptor.setAccessDecisionManager(customAccessDescisionManager());
        customSecurityInterceptor.setSecurityMetadataSource(customSecurityMetadataSource());
        customSecurityInterceptor.setAuthenticationManager(this.authenticationManager());
        return customSecurityInterceptor;
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        // 需要将密码加密后写入数据库
        //DaoAuthenticationProvider authenticationProvider =  new DaoAuthenticationProvider();
        CustomAuthenticationProvider authenticationProvider = new CustomAuthenticationProvider();
        authenticationProvider.setUserDetailsService(userDetailsService());
        // 不隐藏找不到用户异常
        authenticationProvider.setHideUserNotFoundExceptions(false);
        // 指定密码加密所使用的加密器为passwordEncoder()
        authenticationProvider.setPasswordEncoder(passwordEncoder());
        return authenticationProvider;
    } */

}
