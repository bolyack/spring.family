package com.bamboo.jercn.repository;

import com.bamboo.jercn.domain.Role;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Code16----------------------------------------------
 * Created by bamboo on 2017/4/30.
 */
public interface RoleRepository extends JpaRepository<Role, Integer>{

}
